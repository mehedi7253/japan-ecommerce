<template>
  <div>
    <div id="google_translate_element"></div>
  </div>
</template>

<script>
export default {
  name: "Google",
};
</script>
